@extends('layout')

@section('title')
Laravel
@stop

@section('content')
<div class="title">
    <div class="title">{{ $site_title }}</div>
</div>
@stop
