@extends('layout')

@section('title')
Laravel
@stop

@section('content')
<div class="title">
    <div class="title">Laravel 5</div>
</div>
@stop
