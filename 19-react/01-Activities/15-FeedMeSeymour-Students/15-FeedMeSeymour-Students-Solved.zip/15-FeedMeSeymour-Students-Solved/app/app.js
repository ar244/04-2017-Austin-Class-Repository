// Include the Main React Dependencies
var React = require("react");
var ReactDOM = require("react-dom");

// Include the Main Component
var AudreyII = require("./components/AudreyII");

// This code here allows us to render our main component (in this case Seymour)
ReactDOM.render(<AudreyII />, document.getElementById("app"));
