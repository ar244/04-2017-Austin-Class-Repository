// Include the Main React Dependencies
var React = require("react");
var ReactDOM = require("react-dom");

// This code here allows us to render our main component
ReactDOM.render(<h1>Replace this with your "Parent" component</h1>, document.getElementById("app"));
